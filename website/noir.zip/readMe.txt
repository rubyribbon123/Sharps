Noir is an HTML5 template with a CSS style sheet that makes mobile web pages for smartphones.

'Noir' by Azalea Software, Inc. is licensed under the Creative Commons Attribution 3.0 Unported License (CC BY 3.0)

QRdvark.com/templates/